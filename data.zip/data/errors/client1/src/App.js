import { Route, Routes, Navigate, RouterProvider, createBrowserRouter } from "react-router-dom";
import Main from "./components/Main";
import Signup from "./components/Signup";
import Login from "./components/Login";
import "./App.css";
import AddUser from "./components/adduser/AddUser";
import User from "./components/getuser/User";
import Update from "./components/updateuser/Update";

function App() {
	const user = localStorage.getItem("token");

	

	return (
		<Routes>
			{user && <Route path="/" exact element={<Main />} />}
			<Route path="/signup" exact element={<Signup />} />
			<Route path="/login" exact element={<Login />} />
			<Route path="/" element={<Navigate replace to="/login" />} />
			<Route path="/user" exact element={<User />} />
			<Route path="/add" exact element={<AddUser />} />
			<Route path="/update/:id" exact element={<Update />} />
			
		</Routes>

 
	);
}

export default App;




 

