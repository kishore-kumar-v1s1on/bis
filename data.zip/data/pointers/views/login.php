
<h3>You Logged In </h3>
<a href="<?=base_url('user/login')?>">Login</a>
